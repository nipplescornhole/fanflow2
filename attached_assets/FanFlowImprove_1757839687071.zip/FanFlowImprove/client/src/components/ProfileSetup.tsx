import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/hooks/useAuth";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { Music, Star, Headphones, Upload, User } from "lucide-react";

export default function ProfileSetup() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  
  const [userType, setUserType] = useState<"creator" | "expert" | "listener">("listener");
  const [bio, setBio] = useState("");
  const [profileImageUrl, setProfileImageUrl] = useState(user?.profileImageUrl || "");

  // Redirect users who already have complete profiles
  if (user && user.userType) {
    setLocation("/");
    return null;
  }

  const updateProfileMutation = useMutation({
    mutationFn: async (data: { userType: string; bio: string; profileImageUrl?: string }) => {
      const response = await fetch("/api/auth/profile", {
        method: "PUT",
        body: JSON.stringify(data),
        headers: { "Content-Type": "application/json" },
      });
      if (!response.ok) {
        throw new Error('Failed to update profile');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Profilo completato!",
        description: "Il tuo profilo è stato configurato con successo.",
      });
      // Redirect to home after successful profile completion
      setLocation("/");
    },
    onError: (error: any) => {
      toast({
        title: "Errore",
        description: "Impossibile salvare il profilo. Riprova.",
        variant: "destructive",
      });
      console.error("Profile update error:", error);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfileMutation.mutate({
      userType,
      bio,
      profileImageUrl: profileImageUrl || undefined,
    });
  };

  const userTypeOptions = [
    {
      value: "listener",
      label: "Ascoltatore",
      description: "Scopri nuova musica e interagisci con la community",
      icon: <Headphones className="h-8 w-8 text-blue-600" />,
      badge: "Ascolta"
    },
    {
      value: "creator", 
      label: "Creatore",
      description: "Carica e condividi i tuoi contenuti musicali",
      icon: <Music className="h-8 w-8 text-cyan-600" />,
      badge: "Crea"
    },
    {
      value: "expert",
      label: "Esperto Musicale", 
      description: "Condividi la tua expertise e ottieni il badge verificato",
      icon: <Star className="h-8 w-8 text-teal-600" />,
      badge: "Esperto"
    }
  ];

  return (
    <div className="min-h-screen bg-geometric flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        <Card className="glass-card modern-card border-0 rounded-2xl overflow-hidden">
          <CardHeader className="pb-6 text-center bg-gradient-to-r from-blue-50/80 to-cyan-50/80">
            <div className="flex justify-center mb-4">
              <div className="w-20 h-20 bg-gradient-to-br from-blue-500/20 to-cyan-500/20 rounded-full flex items-center justify-center">
                <User className="h-10 w-10 text-blue-600" />
              </div>
            </div>
            <CardTitle className="text-2xl font-bold gradient-text">
              Completa il Tuo Profilo
            </CardTitle>
            <p className="text-sm text-slate-600 font-medium mt-2">
              Benvenuto su FanFlow! Personalizza il tuo account per iniziare la tua esperienza musicale.
            </p>
          </CardHeader>
          
          <CardContent className="p-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Profile Image */}
              <div className="space-y-3">
                <Label className="text-sm font-medium text-slate-700">Foto Profilo</Label>
                <div className="flex items-center gap-4">
                  <Avatar className="h-16 w-16">
                    <AvatarImage src={profileImageUrl} alt="Profile" />
                    <AvatarFallback>
                      {user?.firstName?.charAt(0) || user?.email?.charAt(0) || "U"}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <Input
                      placeholder="URL immagine profilo (opzionale)"
                      value={profileImageUrl}
                      onChange={(e) => setProfileImageUrl(e.target.value)}
                      data-testid="input-profile-image"
                    />
                    <p className="text-xs text-slate-500 mt-1">
                      Inserisci l'URL di un'immagine o lascia vuoto per usare l'avatar predefinito
                    </p>
                  </div>
                </div>
              </div>

              {/* User Type Selection */}
              <div className="space-y-3">
                <Label className="text-sm font-medium text-slate-700">Tipo di Account</Label>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {userTypeOptions.map((option) => (
                    <Card 
                      key={option.value}
                      className={`cursor-pointer transition-all duration-300 hover-elevate ${
                        userType === option.value 
                          ? "ring-2 ring-blue-500 bg-gradient-to-br from-blue-50 to-cyan-50" 
                          : "border-slate-200"
                      }`}
                      onClick={() => setUserType(option.value as any)}
                      data-testid={`option-user-type-${option.value}`}
                    >
                      <CardContent className="p-4 text-center">
                        <div className="flex flex-col items-center space-y-2">
                          {option.icon}
                          <h3 className="font-semibold text-sm text-slate-700">{option.label}</h3>
                          <p className="text-xs text-slate-600 leading-relaxed">{option.description}</p>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              {/* Bio */}
              <div className="space-y-3">
                <Label htmlFor="bio" className="text-sm font-medium text-slate-700">
                  Bio (Opzionale)
                </Label>
                <Textarea
                  id="bio"
                  placeholder="Raccontaci qualcosa di te e della tua passione per la musica..."
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  rows={3}
                  maxLength={500}
                  data-testid="textarea-bio"
                />
                <p className="text-xs text-slate-500">
                  {bio.length}/500 caratteri
                </p>
              </div>

              {/* Submit Button */}
              <div className="pt-4">
                <Button 
                  type="submit" 
                  className="w-full bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 shadow-lg hover:shadow-xl transition-all duration-300"
                  disabled={updateProfileMutation.isPending}
                  data-testid="button-complete-profile"
                >
                  {updateProfileMutation.isPending ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      Salvando...
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <Upload className="h-4 w-4" />
                      Completa Profilo
                    </div>
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}