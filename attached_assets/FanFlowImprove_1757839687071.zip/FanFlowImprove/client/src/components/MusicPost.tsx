import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Heart, MessageCircle, Share2, Play, Pause, Volume2 } from "lucide-react";
import { useState } from "react";

interface MusicPostProps {
  id: string;
  user: {
    name: string;
    avatar: string;
    type: "creator" | "expert" | "listener";
    verified?: boolean;
  };
  title: string;
  genre: string;
  coverImage: string;
  audioUrl?: string;
  videoUrl?: string;
  likes: number;
  comments: number;
  description: string;
  timestamp: string;
}

export default function MusicPost({ 
  user, 
  title, 
  genre, 
  coverImage, 
  audioUrl, 
  videoUrl, 
  likes, 
  comments, 
  description, 
  timestamp 
}: MusicPostProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(likes);

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
    console.log(`${isPlaying ? 'Pausing' : 'Playing'} ${title}`);
  };

  const handleLike = () => {
    setIsLiked(!isLiked);
    setLikeCount(prev => isLiked ? prev - 1 : prev + 1);
    console.log(`${isLiked ? 'Unliked' : 'Liked'} ${title}`);
  };

  const getUserTypeBadge = () => {
    if (user.type === "expert") {
      return <Badge variant="default" className="text-xs">Esperto</Badge>;
    }
    if (user.type === "creator") {
      return <Badge variant="secondary" className="text-xs">Creatore</Badge>;
    }
    return null;
  };

  return (
    <Card className="w-full max-w-md mx-auto hover-elevate" data-testid={`post-${title.toLowerCase().replace(/\s+/g, '-')}`}>
      <CardHeader className="pb-3">
        <div className="flex items-center gap-3">
          <Avatar className="h-10 w-10">
            <AvatarImage src={user.avatar} alt={user.name} />
            <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <h4 className="font-semibold text-sm">{user.name}</h4>
              {user.verified && (
                <div className="w-4 h-4 bg-primary rounded-full flex items-center justify-center">
                  <span className="text-primary-foreground text-xs">✓</span>
                </div>
              )}
              {getUserTypeBadge()}
            </div>
            <p className="text-xs text-muted-foreground">{timestamp}</p>
          </div>
        </div>
      </CardHeader>

      <CardContent className="pb-3">
        <div className="relative group">
          <div className="aspect-square bg-gradient-to-br from-primary/20 to-purple-600/20 rounded-lg overflow-hidden relative">
            <img 
              src={coverImage} 
              alt={title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-all duration-200 flex items-center justify-center">
              <Button
                size="icon"
                variant="secondary"
                className="w-12 h-12 rounded-full opacity-80 group-hover:opacity-100 transition-all"
                onClick={handlePlayPause}
                data-testid={`button-play-${title.toLowerCase().replace(/\s+/g, '-')}`}
              >
                {isPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6" />}
              </Button>
            </div>
          </div>
          
          {/* Audio/Video visualizer placeholder */}
          {isPlaying && (
            <div className="mt-2 flex items-center gap-2 text-primary">
              <Volume2 className="h-4 w-4" />
              <div className="flex-1 h-1 bg-muted rounded-full overflow-hidden">
                <div className="w-1/3 h-full bg-primary rounded-full animate-pulse"></div>
              </div>
            </div>
          )}
        </div>

        <div className="mt-3 space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-base" data-testid={`text-title-${title.toLowerCase().replace(/\s+/g, '-')}`}>{title}</h3>
            <Badge variant="outline" className="text-xs">{genre}</Badge>
          </div>
          <p className="text-sm text-muted-foreground line-clamp-2">{description}</p>
        </div>
      </CardContent>

      <CardFooter className="pt-0 flex justify-between">
        <div className="flex items-center gap-4">
          <Button 
            variant="ghost" 
            size="sm" 
            className={`gap-2 ${isLiked ? 'text-red-500' : ''}`}
            onClick={handleLike}
            data-testid={`button-like-${title.toLowerCase().replace(/\s+/g, '-')}`}
          >
            <Heart className={`h-4 w-4 ${isLiked ? 'fill-current' : ''}`} />
            <span>{likeCount}</span>
          </Button>
          <Button variant="ghost" size="sm" className="gap-2" data-testid={`button-comment-${title.toLowerCase().replace(/\s+/g, '-')}`}>
            <MessageCircle className="h-4 w-4" />
            <span>{comments}</span>
          </Button>
        </div>
        <Button variant="ghost" size="sm" data-testid={`button-share-${title.toLowerCase().replace(/\s+/g, '-')}`}>
          <Share2 className="h-4 w-4" />
        </Button>
      </CardFooter>
    </Card>
  );
}