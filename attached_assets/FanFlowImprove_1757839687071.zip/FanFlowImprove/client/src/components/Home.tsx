import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { Upload, Music, TrendingUp, Users, Heart } from "lucide-react";
import MusicFeed from "./MusicFeed";

export default function Home() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState("feed");

  // TODO: Remove mock data functionality
  const userStats = {
    followers: 142,
    following: 67,
    postsLiked: 234,
    postsShared: 12
  };

  const trendingGenres = ["Electronic", "Indie Rock", "Hip-Hop", "Jazz", "Pop"];

  return (
    <div className="min-h-screen bg-geometric">
      <div className="container mx-auto px-4 py-6">
        {/* Welcome Section */}
        <div className="mb-8 relative">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-400/5 via-cyan-400/5 to-teal-400/5 rounded-2xl blur-xl"></div>
          <Card className="glass-card modern-card bg-gradient-to-r from-blue-50/80 to-cyan-50/80 border-0 rounded-2xl overflow-hidden">
            <CardHeader className="pb-6">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-2xl font-bold gradient-text">
                    Benvenuto, {user?.firstName || "Musicista"}!
                  </CardTitle>
                  <p className="text-sm text-slate-600 font-medium mt-2">
                    Scopri nuova musica e condividi la tua passione con la community
                  </p>
                </div>
                <Button 
                  className="gap-2 bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 shadow-lg hover:shadow-xl transition-all duration-300" 
                  data-testid="button-upload-content"
                >
                  <Upload className="h-4 w-4" />
                  Carica Contenuto
                </Button>
              </div>
            </CardHeader>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* User Stats */}
            <Card className="glass-card modern-card border-0 rounded-2xl">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2 text-slate-700 font-bold">
                  <Users className="h-5 w-5 text-blue-600" />
                  Le Tue Statistiche
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div className="p-3 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl">
                    <div className="text-2xl font-bold gradient-text" data-testid="stat-followers">
                      {userStats.followers}
                    </div>
                    <div className="text-xs text-slate-600 font-medium">Followers</div>
                  </div>
                  <div className="p-3 bg-gradient-to-br from-cyan-50 to-teal-50 rounded-xl">
                    <div className="text-2xl font-bold gradient-text" data-testid="stat-following">
                      {userStats.following}
                    </div>
                    <div className="text-xs text-slate-600 font-medium">Following</div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4 text-center pt-2 border-t">
                  <div>
                    <div className="text-lg font-semibold text-muted-foreground" data-testid="stat-likes">
                      {userStats.postsLiked}
                    </div>
                    <div className="text-xs text-muted-foreground">Likes</div>
                  </div>
                  <div>
                    <div className="text-lg font-semibold text-muted-foreground" data-testid="stat-shares">
                      {userStats.postsShared}
                    </div>
                    <div className="text-xs text-muted-foreground">Condivisioni</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Trending Genres */}
            <Card className="glass-card modern-card border-0 rounded-2xl">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2 text-slate-700 font-bold">
                  <TrendingUp className="h-5 w-5 text-blue-600" />
                  Generi in Tendenza
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {trendingGenres.map((genre, index) => (
                    <div key={genre} className="flex items-center justify-between">
                      <Badge 
                        variant={index < 3 ? "default" : "secondary"} 
                        className={`w-full justify-between transition-all duration-300 ${
                          index < 3 
                            ? "bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 text-white" 
                            : "bg-gradient-to-r from-blue-100 to-cyan-100 text-blue-700 border-0"
                        }`}
                        data-testid={`trending-genre-${genre.toLowerCase().replace(/\s+/g, '-')}`}
                      >
                        <span className="font-medium">{genre}</span>
                        <span className="text-xs font-bold">#{index + 1}</span>
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="glass-card modern-card border-0 rounded-2xl">
              <CardHeader>
                <CardTitle className="text-lg text-slate-700 font-bold">Azioni Rapide</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" className="w-full justify-start gap-2 border-blue-200 text-blue-700 hover:bg-blue-50 glass-card transition-all duration-300" data-testid="button-create-playlist">
                  <Music className="h-4 w-4" />
                  Crea Playlist
                </Button>
                <Button variant="outline" className="w-full justify-start gap-2 border-cyan-200 text-cyan-700 hover:bg-cyan-50 glass-card transition-all duration-300" data-testid="button-explore-artists">
                  <Users className="h-4 w-4" />
                  Esplora Artisti
                </Button>
                <Button variant="outline" className="w-full justify-start gap-2 border-teal-200 text-teal-700 hover:bg-teal-50 glass-card transition-all duration-300" data-testid="button-my-likes">
                  <Heart className="h-4 w-4" />
                  I Miei Like
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {/* Navigation Tabs */}
            <div className="flex gap-2 mb-6 border-b">
              <Button
                variant={activeTab === "feed" ? "default" : "ghost"}
                onClick={() => setActiveTab("feed")}
                className="rounded-b-none"
                data-testid="tab-feed"
              >
                Feed Musicale
              </Button>
              <Button
                variant={activeTab === "discover" ? "default" : "ghost"}
                onClick={() => setActiveTab("discover")}
                className="rounded-b-none"
                data-testid="tab-discover"
              >
                Scopri
              </Button>
              <Button
                variant={activeTab === "following" ? "default" : "ghost"}
                onClick={() => setActiveTab("following")}
                className="rounded-b-none"
                data-testid="tab-following"
              >
                Following
              </Button>
            </div>

            {/* Content based on active tab */}
            {activeTab === "feed" && <MusicFeed />}
            {activeTab === "discover" && (
              <Card>
                <CardContent className="py-8 text-center">
                  <Music className="h-12 w-12 text-primary mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Scopri Nuova Musica</h3>
                  <p className="text-muted-foreground">
                    Questa sezione conterrà raccomandazioni personalizzate basate sui tuoi gusti musicali.
                  </p>
                </CardContent>
              </Card>
            )}
            {activeTab === "following" && (
              <Card>
                <CardContent className="py-8 text-center">
                  <Users className="h-12 w-12 text-primary mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">I Tuoi Following</h3>
                  <p className="text-muted-foreground">
                    Qui vedrai i contenuti delle persone che segui.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}