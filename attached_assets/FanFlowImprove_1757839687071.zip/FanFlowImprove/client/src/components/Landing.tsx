import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Music, Users, Headphones, Mic, Star, Play } from "lucide-react";
import fanflowLogo from '@assets/logo senza sfondo 2_1757788923736.png';
// TODO: Replace with actual hero image import
const heroImage = "/demo-hero.jpg";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  const features = [
    {
      icon: <Mic className="h-8 w-8" />,
      title: "Creatori",
      description: "Carica i tuoi brani e video musicali. Condividi la tua arte con la community.",
      badge: "Crea"
    },
    {
      icon: <Star className="h-8 w-8" />,
      title: "Esperti Musicali",
      description: "Condividi la tua expertise e ottieni il badge verificato. Guida la conversazione musicale.",
      badge: "Esperto"
    },
    {
      icon: <Headphones className="h-8 w-8" />,
      title: "Ascoltatori",
      description: "Scopri nuova musica, commenta e interagisci con artisti e altri appassionati.",
      badge: "Ascolta"
    }
  ];

  const stats = [
    { label: "Artisti Attivi", value: "10K+" },
    { label: "Brani Condivisi", value: "50K+" },
    { label: "Community Members", value: "100K+" }
  ];

  return (
    <div className="min-h-screen bg-geometric">
      {/* Hero Section */}
      <section className="relative py-2 overflow-hidden">
        {/* Modern geometric background */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-cyan-50 to-teal-50">
          <div className="absolute inset-0 bg-gradient-to-tr from-blue-600/5 via-transparent to-cyan-400/5"></div>
          {/* Floating geometric shapes */}
          <div className="absolute top-20 left-10 w-32 h-32 bg-blue-400/10 rounded-full blur-xl float-animation"></div>
          <div className="absolute top-40 right-20 w-24 h-24 bg-cyan-400/10 rounded-lg rotate-45 blur-lg float-animation" style={{animationDelay: '2s'}}></div>
          <div className="absolute bottom-20 left-1/4 w-40 h-40 bg-teal-400/8 rounded-full blur-2xl float-animation" style={{animationDelay: '4s'}}></div>
          <div className="absolute top-60 right-1/3 w-16 h-16 bg-blue-500/15 rounded-full blur-md float-animation" style={{animationDelay: '1s'}}></div>
        </div>
        <div className="relative container mx-auto px-4 text-center">
          <div className="max-w-4xl mx-auto">
            <div className="flex justify-center">
              <img 
                src={fanflowLogo} 
                alt="FanFlow" 
            className="h-40 md:h-52 w-auto"
                data-testid="fanflow-hero-logo"
              />
            </div>
            <h1 className="text-3xl md:text-4xl font-bold gradient-text mt-4 mb-4">
              Il Social Network della Musica
            </h1>
            <p className="text-sm md:text-base text-slate-600 max-w-2xl mx-auto font-medium mb-6">
              Dove creatori, esperti e ascoltatori si incontrano per condividere la passione per la musica
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="text-sm px-8 py-3 bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 shadow-lg hover:shadow-xl transition-all duration-300"
                onClick={handleLogin}
                data-testid="button-join-community"
              >
                <Play className="mr-2 h-4 w-4" />
                Unisciti alla Community
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="text-sm px-8 py-3 border-blue-200 text-blue-700 hover:bg-blue-50 glass-card modern-card"
                data-testid="button-discover"
              >
                <Music className="mr-2 h-4 w-4" />
                Scopri di Più
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-4 bg-gradient-to-b from-transparent to-blue-50/50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            {stats.map((stat, index) => (
              <div key={index} className="glass-card modern-card p-8 rounded-2xl space-y-3">
                <div className="text-2xl md:text-3xl font-bold gradient-text" data-testid={`stat-value-${index}`}>
                  {stat.value}
                </div>
                <div className="text-sm font-medium text-slate-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-6 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-blue-50/50 via-cyan-50/30 to-teal-50/50"></div>
        <div className="relative container mx-auto px-4">
          <div className="text-center mb-4">
            <h2 className="text-2xl md:text-3xl font-bold gradient-text mb-2">
              Tre Modi di Vivere la Musica
            </h2>
            <p className="text-sm text-slate-600 font-medium max-w-2xl mx-auto">
              Scegli il tuo ruolo nella community musicale più vibrante del web
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="text-center glass-card modern-card border-0 rounded-2xl overflow-hidden h-full">
                <CardHeader className="pb-6 pt-8 relative">
                  <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-blue-400/10 to-cyan-400/10 rounded-full blur-xl"></div>
                  <div className="relative mx-auto mb-4 w-16 h-16 bg-gradient-to-br from-blue-500/20 to-cyan-500/20 rounded-2xl flex items-center justify-center text-blue-600 shadow-lg">
                    {feature.icon}
                  </div>
                  <CardTitle className="text-lg font-bold text-slate-700 mb-4">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent className="px-6 pb-8">
                  <CardDescription className="text-sm leading-relaxed text-slate-600 font-medium text-center mb-4">
                    {feature.description}
                  </CardDescription>
                  <div className="flex justify-center">
                    <Badge variant="secondary" className="text-xs bg-gradient-to-r from-blue-100 to-cyan-100 text-blue-700 border-0">
                      {feature.badge}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-600 via-cyan-500 to-teal-400">
          <div className="absolute inset-0 bg-gradient-to-t from-black/10 to-transparent"></div>
          {/* Geometric shapes for visual interest */}
          <div className="absolute top-10 left-10 w-40 h-40 bg-white/5 rounded-full blur-2xl"></div>
          <div className="absolute bottom-10 right-10 w-32 h-32 bg-white/5 rounded-lg rotate-45 blur-xl"></div>
          <div className="absolute top-1/2 left-1/3 w-24 h-24 bg-white/3 rounded-full blur-lg"></div>
        </div>
        <div className="relative container mx-auto px-4 text-center">
          <div className="max-w-3xl mx-auto space-y-6">
            <h2 className="text-2xl md:text-3xl font-bold text-white">
              Pronto a Condividere la Tua Musica?
            </h2>
            <p className="text-sm text-white/90 font-medium">
              Unisciti a migliaia di musicisti, produttori e appassionati che stanno già costruendo il futuro della musica sociale.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
              <Button 
                size="lg" 
                className="text-sm px-8 py-3 bg-white/20 hover:bg-white/30 text-white border-white/30 backdrop-blur-sm transition-all duration-300"
                onClick={handleLogin}
                data-testid="button-start-journey"
              >
                <Users className="mr-2 h-4 w-4" />
                Inizia il Tuo Viaggio
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}