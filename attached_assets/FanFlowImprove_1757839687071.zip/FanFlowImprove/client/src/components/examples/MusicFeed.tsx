import MusicFeed from '../MusicFeed';

export default function MusicFeedExample() {
  return (
    <div className="p-4">
      <MusicFeed />
    </div>
  );
}