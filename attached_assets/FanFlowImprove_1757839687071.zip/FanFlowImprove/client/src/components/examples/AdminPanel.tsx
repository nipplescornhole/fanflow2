import AdminPanel from '../AdminPanel';

export default function AdminPanelExample() {
  return (
    <div className="p-4">
      <AdminPanel />
    </div>
  );
}