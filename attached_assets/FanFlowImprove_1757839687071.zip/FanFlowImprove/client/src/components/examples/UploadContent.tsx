import UploadContent from '../UploadContent';

export default function UploadContentExample() {
  return (
    <div className="p-4">
      <UploadContent />
    </div>
  );
}