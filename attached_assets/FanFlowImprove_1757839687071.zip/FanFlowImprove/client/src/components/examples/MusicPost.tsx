import MusicPost from '../MusicPost';

// TODO: Replace with actual imports when images are ready
export default function MusicPostExample() {
  return (
    <div className="p-4 space-y-4">
      <MusicPost
        id="1"
        user={{
          name: "Sofia Martinez",
          avatar: "/demo-avatar.jpg",
          type: "expert",
          verified: true
        }}
        title="Future Bass Drop"
        genre="Electronic"
        coverImage="/demo-cover.jpg"
        audioUrl="/demo-audio.mp3"
        likes={127}
        comments={23}
        description="Un nuovo brano elettronico che mescola elementi future bass con sonorità ambient. Perfetto per le playlist chill."
        timestamp="2 ore fa"
      />
    </div>
  );
}