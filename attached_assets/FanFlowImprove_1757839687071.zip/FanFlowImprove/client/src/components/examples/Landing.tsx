import Landing from '../Landing';

export default function LandingExample() {
  return <Landing />;
}