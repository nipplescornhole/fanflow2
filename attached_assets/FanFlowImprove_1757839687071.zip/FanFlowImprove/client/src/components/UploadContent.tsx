import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Upload, Music, Video, Image, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const genres = ["Pop", "Rock", "Hip-Hop", "Electronic", "Jazz", "Classical", "Country", "Reggae"];

export default function UploadContent() {
  const [contentType, setContentType] = useState<"audio" | "video">("audio");
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    genre: "",
    audioFile: null as File | null,
    videoFile: null as File | null,
    coverImage: null as File | null
  });
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();

  const handleFileChange = (fileType: keyof typeof formData, file: File | null) => {
    setFormData(prev => ({
      ...prev,
      [fileType]: file
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title || !formData.genre) {
      toast({
        title: "Errore",
        description: "Compila tutti i campi obbligatori",
        variant: "destructive"
      });
      return;
    }

    if (contentType === "audio" && !formData.audioFile) {
      toast({
        title: "Errore", 
        description: "Seleziona un file audio",
        variant: "destructive"
      });
      return;
    }

    if (contentType === "video" && !formData.videoFile) {
      toast({
        title: "Errore",
        description: "Seleziona un file video", 
        variant: "destructive"
      });
      return;
    }

    setIsUploading(true);
    
    // TODO: Remove mock functionality - replace with real upload
    setTimeout(() => {
      console.log("Uploading content:", formData);
      toast({
        title: "Successo!",
        description: "Il tuo contenuto è stato caricato con successo",
      });
      setIsUploading(false);
      // Reset form
      setFormData({
        title: "",
        description: "",
        genre: "",
        audioFile: null,
        videoFile: null,
        coverImage: null
      });
    }, 2000);
  };

  const removeFile = (fileType: keyof typeof formData) => {
    handleFileChange(fileType, null);
  };

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Upload className="h-6 w-6" />
          Carica Nuovo Contenuto
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Content Type Selection */}
          <div className="space-y-2">
            <Label>Tipo di Contenuto</Label>
            <div className="flex gap-2">
              <Button
                type="button"
                variant={contentType === "audio" ? "default" : "outline"}
                className="flex-1 gap-2"
                onClick={() => setContentType("audio")}
                data-testid="button-select-audio"
              >
                <Music className="h-4 w-4" />
                Audio
              </Button>
              <Button
                type="button"
                variant={contentType === "video" ? "default" : "outline"}
                className="flex-1 gap-2"
                onClick={() => setContentType("video")}
                data-testid="button-select-video"
              >
                <Video className="h-4 w-4" />
                Video
              </Button>
            </div>
          </div>

          {/* Title */}
          <div className="space-y-2">
            <Label htmlFor="title">Titolo *</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
              placeholder="Inserisci il titolo del brano"
              data-testid="input-title"
            />
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description">Descrizione</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Racconta qualcosa sul tuo brano..."
              rows={3}
              data-testid="textarea-description"
            />
          </div>

          {/* Genre */}
          <div className="space-y-2">
            <Label>Genere *</Label>
            <Select value={formData.genre} onValueChange={(value) => setFormData(prev => ({ ...prev, genre: value }))}>
              <SelectTrigger data-testid="select-genre">
                <SelectValue placeholder="Seleziona un genere" />
              </SelectTrigger>
              <SelectContent>
                {genres.map(genre => (
                  <SelectItem key={genre} value={genre}>{genre}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* File Upload - Audio */}
          {contentType === "audio" && (
            <div className="space-y-2">
              <Label>File Audio *</Label>
              <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-4">
                {formData.audioFile ? (
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Music className="h-4 w-4 text-primary" />
                      <span className="text-sm">{formData.audioFile.name}</span>
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeFile("audioFile")}
                      data-testid="button-remove-audio"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <label className="cursor-pointer">
                    <input
                      type="file"
                      accept="audio/*"
                      className="hidden"
                      onChange={(e) => handleFileChange("audioFile", e.target.files?.[0] || null)}
                      data-testid="input-audio-file"
                    />
                    <div className="text-center">
                      <Music className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                      <p className="text-sm text-muted-foreground">
                        Clicca per caricare un file audio
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        MP3, WAV, FLAC (max 50MB)
                      </p>
                    </div>
                  </label>
                )}
              </div>
            </div>
          )}

          {/* File Upload - Video */}
          {contentType === "video" && (
            <div className="space-y-2">
              <Label>File Video *</Label>
              <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-4">
                {formData.videoFile ? (
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Video className="h-4 w-4 text-primary" />
                      <span className="text-sm">{formData.videoFile.name}</span>
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeFile("videoFile")}
                      data-testid="button-remove-video"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <label className="cursor-pointer">
                    <input
                      type="file"
                      accept="video/*"
                      className="hidden"
                      onChange={(e) => handleFileChange("videoFile", e.target.files?.[0] || null)}
                      data-testid="input-video-file"
                    />
                    <div className="text-center">
                      <Video className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                      <p className="text-sm text-muted-foreground">
                        Clicca per caricare un file video
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        MP4, MOV, AVI (max 100MB)
                      </p>
                    </div>
                  </label>
                )}
              </div>
            </div>
          )}

          {/* Cover Image */}
          <div className="space-y-2">
            <Label>Immagine di Copertina {contentType === "audio" && "*"}</Label>
            <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-4">
              {formData.coverImage ? (
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Image className="h-4 w-4 text-primary" />
                    <span className="text-sm">{formData.coverImage.name}</span>
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => removeFile("coverImage")}
                    data-testid="button-remove-cover"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <label className="cursor-pointer">
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => handleFileChange("coverImage", e.target.files?.[0] || null)}
                    data-testid="input-cover-image"
                  />
                  <div className="text-center">
                    <Image className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                    <p className="text-sm text-muted-foreground">
                      Clicca per caricare un'immagine di copertina
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      PNG, JPG, GIF (max 10MB)
                    </p>
                  </div>
                </label>
              )}
            </div>
          </div>

          {/* Submit Button */}
          <Button 
            type="submit" 
            className="w-full" 
            disabled={isUploading}
            data-testid="button-submit-upload"
          >
            {isUploading ? (
              <>
                <Upload className="h-4 w-4 mr-2 animate-spin" />
                Caricamento in corso...
              </>
            ) : (
              <>
                <Upload className="h-4 w-4 mr-2" />
                Carica Contenuto
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}