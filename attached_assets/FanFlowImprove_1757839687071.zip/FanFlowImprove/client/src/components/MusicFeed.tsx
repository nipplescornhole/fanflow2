import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Filter, TrendingUp, Clock } from "lucide-react";
import { Input } from "@/components/ui/input";
import MusicPost from "./MusicPost";

// TODO: Remove mock data functionality
const mockPosts = [
  {
    id: "1",
    user: {
      name: "Sofia Martinez",
      avatar: "/demo-avatar-1.jpg",
      type: "expert" as const,
      verified: true
    },
    title: "Future Bass Drop",
    genre: "Electronic",
    coverImage: "/demo-cover-1.jpg",
    audioUrl: "/demo-audio-1.mp3",
    likes: 127,
    comments: 23,
    description: "Un nuovo brano elettronico che mescola elementi future bass con sonorità ambient.",
    timestamp: "2 ore fa"
  },
  {
    id: "2",
    user: {
      name: "Marco Rossi",
      avatar: "/demo-avatar-2.jpg",
      type: "creator" as const,
      verified: false
    },
    title: "Indie Vibes",
    genre: "Rock",
    coverImage: "/demo-cover-2.jpg",
    audioUrl: "/demo-audio-2.mp3",
    likes: 89,
    comments: 15,
    description: "Chitarre indie e melodie nostalgiche per un viaggio sonoro unico.",
    timestamp: "4 ore fa"
  }
];

const genres = ["Tutti", "Pop", "Rock", "Hip-Hop", "Electronic", "Jazz", "Classical", "Country", "Reggae"];
const userTypes = ["Tutti", "Esperti", "Creatori", "Verificati"];
const sortOptions = ["Recenti", "Popolari", "Trending"];

export default function MusicFeed() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedGenre, setSelectedGenre] = useState("Tutti");
  const [selectedUserType, setSelectedUserType] = useState("Tutti");
  const [sortBy, setSortBy] = useState("Recenti");
  const [posts] = useState(mockPosts); // TODO: Replace with real data fetching

  const handleSearch = (value: string) => {
    setSearchQuery(value);
    console.log("Searching for:", value);
  };

  const filteredPosts = posts.filter(post => {
    const matchesSearch = post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         post.user.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesGenre = selectedGenre === "Tutti" || post.genre === selectedGenre;
    const matchesUserType = selectedUserType === "Tutti" || 
                           (selectedUserType === "Esperti" && post.user.type === "expert") ||
                           (selectedUserType === "Creatori" && post.user.type === "creator") ||
                           (selectedUserType === "Verificati" && post.user.verified);
    
    return matchesSearch && matchesGenre && matchesUserType;
  });

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Search and Filters */}
      <Card className="glass-card modern-card border-0 rounded-2xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-slate-700 font-bold">
            <Search className="h-5 w-5 text-blue-600" />
            Esplora Musica
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Cerca artisti, brani, generi..."
              value={searchQuery}
              onChange={(e) => handleSearch(e.target.value)}
              className="pl-10"
              data-testid="input-search"
            />
          </div>

          {/* Filters */}
          <div className="flex flex-wrap gap-4">
            <div className="flex-1 min-w-[140px]">
              <Select value={selectedGenre} onValueChange={setSelectedGenre}>
                <SelectTrigger data-testid="select-genre">
                  <SelectValue placeholder="Genere" />
                </SelectTrigger>
                <SelectContent>
                  {genres.map(genre => (
                    <SelectItem key={genre} value={genre}>{genre}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex-1 min-w-[140px]">
              <Select value={selectedUserType} onValueChange={setSelectedUserType}>
                <SelectTrigger data-testid="select-user-type">
                  <SelectValue placeholder="Tipo Utente" />
                </SelectTrigger>
                <SelectContent>
                  {userTypes.map(type => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex-1 min-w-[140px]">
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger data-testid="select-sort">
                  <SelectValue placeholder="Ordina per" />
                </SelectTrigger>
                <SelectContent>
                  {sortOptions.map(option => (
                    <SelectItem key={option} value={option}>{option}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Active Filters */}
          <div className="flex flex-wrap gap-2">
            {selectedGenre !== "Tutti" && (
              <Badge className="gap-1 bg-gradient-to-r from-blue-100 to-cyan-100 text-blue-700 border-0">
                <Filter className="h-3 w-3" />
                {selectedGenre}
              </Badge>
            )}
            {selectedUserType !== "Tutti" && (
              <Badge className="gap-1 bg-gradient-to-r from-cyan-100 to-teal-100 text-cyan-700 border-0">
                <Filter className="h-3 w-3" />
                {selectedUserType}
              </Badge>
            )}
            {sortBy === "Popolari" && (
              <Badge className="gap-1 bg-gradient-to-r from-blue-600 to-cyan-500 text-white border-0">
                <TrendingUp className="h-3 w-3" />
                Popolari
              </Badge>
            )}
            {sortBy === "Recenti" && (
              <Badge className="gap-1 bg-gradient-to-r from-teal-100 to-blue-100 text-teal-700 border-0">
                <Clock className="h-3 w-3" />
                Recenti
              </Badge>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Feed Results */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold gradient-text" data-testid="text-results-count">
            {filteredPosts.length} {filteredPosts.length === 1 ? 'risultato' : 'risultati'}
          </h2>
        </div>

        {/* Posts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPosts.map(post => (
            <MusicPost key={post.id} {...post} />
          ))}
        </div>

        {filteredPosts.length === 0 && (
          <Card className="glass-card border-0 rounded-2xl">
            <CardContent className="py-8 text-center">
              <Search className="h-12 w-12 text-blue-400 mx-auto mb-4" />
              <h3 className="text-lg font-bold gradient-text mb-2">Nessun risultato trovato</h3>
              <p className="text-slate-600 font-medium">
                Prova a modificare i filtri o cerca qualcosa di diverso.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}