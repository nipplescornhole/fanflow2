import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Shield, Users, FileText, CheckCircle, XCircle, Star } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import fanflowLogo from '@assets/logo senza sfondo_1757778274351.png';

// TODO: Remove mock data functionality
const mockUsers = [
  {
    id: "1",
    firstName: "Sofia",
    lastName: "Martinez",
    email: "sofia@example.com",
    userType: "expert",
    verified: true,
    profileImageUrl: "/demo-avatar-1.jpg"
  },
  {
    id: "2", 
    firstName: "Marco",
    lastName: "Rossi",
    email: "marco@example.com",
    userType: "creator",
    verified: false,
    profileImageUrl: "/demo-avatar-2.jpg"
  }
];

const mockExpertRequests = [
  {
    id: "1",
    userId: "2",
    user: mockUsers[1],
    description: "Laureato in Composizione presso il Conservatorio di Milano. 10 anni di esperienza come produttore musicale.",
    specialization: "Produzione Musicale",
    documents: ["diploma_conservatorio.pdf", "certificato_produzione.pdf"],
    status: "pending" as "pending" | "approved" | "rejected",
    createdAt: "2024-01-15"
  }
];

export default function AdminPanel() {
  const [users, setUsers] = useState(mockUsers);
  const [expertRequests, setExpertRequests] = useState(mockExpertRequests);
  const { toast } = useToast();

  const handleVerifyUser = (userId: string) => {
    setUsers(prev => prev.map(user => 
      user.id === userId ? { ...user, verified: true } : user
    ));
    toast({
      title: "Utente Verificato",
      description: "L'utente ha ricevuto il badge verificato",
    });
    console.log("Verified user:", userId);
  };

  const handleRemoveVerification = (userId: string) => {
    setUsers(prev => prev.map(user => 
      user.id === userId ? { ...user, verified: false } : user
    ));
    toast({
      title: "Verifica Rimossa",
      description: "Il badge verificato è stato rimosso dall'utente",
    });
    console.log("Removed verification for user:", userId);
  };

  const handleExpertRequest = (requestId: string, action: "approve" | "reject") => {
    const request = expertRequests.find(r => r.id === requestId);
    if (request && action === "approve") {
      // Update user type to expert
      setUsers(prev => prev.map(user => 
        user.id === request.userId ? { ...user, userType: "expert", verified: true } : user
      ));
    }

    setExpertRequests(prev => prev.map(req => 
      req.id === requestId ? { ...req, status: action === "approve" ? "approved" : "rejected" } : req
    ));

    toast({
      title: action === "approve" ? "Richiesta Approvata" : "Richiesta Rifiutata",
      description: action === "approve" 
        ? "L'utente è ora un Esperto Musicale verificato"
        : "La richiesta di badge esperto è stata rifiutata",
    });
    console.log(`${action} expert request:`, requestId);
  };

  const getUserTypeBadge = (userType: string) => {
    switch (userType) {
      case "expert":
        return <Badge variant="default">Esperto</Badge>;
      case "creator":
        return <Badge variant="secondary">Creatore</Badge>;
      default:
        return <Badge variant="outline">Ascoltatore</Badge>;
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <Shield className="h-6 w-6" />
            <span>Pannello Amministrazione</span>
            <img 
              src={fanflowLogo} 
              alt="FanFlow" 
              className="h-16 w-auto"
            />
          </CardTitle>
        </CardHeader>
      </Card>

      <Tabs defaultValue="users" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="users" data-testid="tab-users">
            <Users className="h-4 w-4 mr-2" />
            Gestione Utenti
          </TabsTrigger>
          <TabsTrigger value="expert-requests" data-testid="tab-expert-requests">
            <FileText className="h-4 w-4 mr-2" />
            Richieste Esperto
          </TabsTrigger>
          <TabsTrigger value="analytics" data-testid="tab-analytics">
            <Star className="h-4 w-4 mr-2" />
            Statistiche
          </TabsTrigger>
        </TabsList>

        <TabsContent value="users" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Utenti Registrati ({users.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {users.map(user => (
                  <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <Avatar>
                        <AvatarImage src={user.profileImageUrl} alt={user.firstName} />
                        <AvatarFallback>{user.firstName?.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <h4 className="font-semibold">{user.firstName} {user.lastName}</h4>
                        <p className="text-sm text-muted-foreground">{user.email}</p>
                        <div className="flex items-center gap-2 mt-1">
                          {getUserTypeBadge(user.userType)}
                          {user.verified && (
                            <div className="flex items-center gap-1 text-green-600">
                              <CheckCircle className="h-4 w-4" />
                              <span className="text-xs">Verificato</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      {user.verified ? (
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleRemoveVerification(user.id)}
                          data-testid={`button-remove-verification-${user.id}`}
                        >
                          <XCircle className="h-4 w-4 mr-1" />
                          Rimuovi Verifica
                        </Button>
                      ) : (
                        <Button 
                          variant="default" 
                          size="sm"
                          onClick={() => handleVerifyUser(user.id)}
                          data-testid={`button-verify-${user.id}`}
                        >
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Verifica
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="expert-requests" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Richieste Badge Esperto ({expertRequests.filter(r => r.status === "pending").length} in attesa)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {expertRequests.map(request => (
                  <div key={request.id} className="border rounded-lg p-4 space-y-4">
                    <div className="flex items-center gap-4">
                      <Avatar>
                        <AvatarImage src={request.user.profileImageUrl} alt={request.user.firstName} />
                        <AvatarFallback>{request.user.firstName?.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <h4 className="font-semibold">{request.user.firstName} {request.user.lastName}</h4>
                        <p className="text-sm text-muted-foreground">{request.user.email}</p>
                        <Badge variant="outline" className="mt-1">
                          Specializzazione: {request.specialization}
                        </Badge>
                      </div>
                      <Badge 
                        variant={
                          request.status === "pending" ? "secondary" : 
                          request.status === "approved" ? "default" : 
                          "destructive"
                        }
                      >
                        {request.status === "pending" ? "In Attesa" : 
                         request.status === "approved" ? "Approvata" : "Rifiutata"}
                      </Badge>
                    </div>

                    <div>
                      <h5 className="font-medium mb-2">Descrizione</h5>
                      <p className="text-sm text-muted-foreground">{request.description}</p>
                    </div>

                    <div>
                      <h5 className="font-medium mb-2">Documenti Allegati ({request.documents.length})</h5>
                      <div className="flex flex-wrap gap-2">
                        {request.documents.map((doc, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {doc}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    {request.status === "pending" && (
                      <div className="flex gap-2">
                        <Button 
                          variant="default"
                          size="sm"
                          onClick={() => handleExpertRequest(request.id, "approve")}
                          data-testid={`button-approve-${request.id}`}
                        >
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Approva
                        </Button>
                        <Button 
                          variant="destructive"
                          size="sm"
                          onClick={() => handleExpertRequest(request.id, "reject")}
                          data-testid={`button-reject-${request.id}`}
                        >
                          <XCircle className="h-4 w-4 mr-1" />
                          Rifiuta
                        </Button>
                      </div>
                    )}
                  </div>
                ))}

                {expertRequests.filter(r => r.status === "pending").length === 0 && (
                  <div className="text-center py-8">
                    <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">Nessuna richiesta in attesa</h3>
                    <p className="text-muted-foreground">
                      Tutte le richieste di badge esperto sono state elaborate.
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-primary">{users.length}</div>
                <p className="text-muted-foreground">Utenti Totali</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-green-600">{users.filter(u => u.verified).length}</div>
                <p className="text-muted-foreground">Utenti Verificati</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-blue-600">{users.filter(u => u.userType === "expert").length}</div>
                <p className="text-muted-foreground">Esperti Musicali</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Distribuzione Tipi Utente</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {["creator", "expert", "listener"].map(type => {
                  const count = users.filter(u => u.userType === type).length;
                  const percentage = (count / users.length) * 100;
                  
                  return (
                    <div key={type} className="flex items-center justify-between">
                      <span className="capitalize">{type === "creator" ? "Creatori" : type === "expert" ? "Esperti" : "Ascoltatori"}</span>
                      <div className="flex items-center gap-2">
                        <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-primary rounded-full"
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                        <span className="text-sm font-medium">{count}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}