import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/useAuth";
import NotFound from "@/pages/not-found";
import Header from "@/components/Header";
import Landing from "@/components/Landing";
import Home from "@/components/Home";
import ProfileSetup from "@/components/ProfileSetup";

function Router() {
  const { isAuthenticated, isLoading, user } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-muted-foreground">Caricamento...</p>
        </div>
      </div>
    );
  }

  // Check if user needs to complete profile setup
  const needsProfileSetup = isAuthenticated && (!user || !user.userType);
  
  if (needsProfileSetup) {
    return <ProfileSetup />;
  }

  return (
    <div className="min-h-screen">
      <Header />
      <Switch>
        {isAuthenticated ? (
          <>
            <Route path="/" component={Home} />
            <Route path="/setup-profile" component={ProfileSetup} />
            <Route component={NotFound} />
          </>
        ) : (
          <>
            <Route path="/" component={Landing} />
            <Route component={NotFound} />
          </>
        )}
      </Switch>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
