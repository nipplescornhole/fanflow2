# FanFlow - Social Music Network Design Guidelines

## Design Approach: Reference-Based
**Primary Reference**: Instagram + Spotify hybrid approach
- **Justification**: Music-focused social platform requiring visual appeal for content discovery and social engagement
- **Key Patterns**: Card-based content feeds, profile-centric design, music player integration, vibrant color usage

## Core Design Elements

### A. Color Palette
**Primary Brand Colors** (inspired by FanFlow logo):
- Primary Brand: 200 85% 55% (electric blue - light mode) / 200 85% 65% (electric blue - dark mode)
- Secondary Brand: 180 85% 45% (teal/cyan) / 180 85% 75% (teal/cyan - dark mode)
- Accent: 180 15% 92% (light teal) / 180 12% 16% (dark teal)

**Dark Mode**:
- Background: 210 15% 8% (deep navy-black)
- Surface: 210 12% 12% (elevated dark gray)
- Text Primary: 0 0% 95% (near white)
- Text Secondary: 0 0% 70% (muted gray)

**Light Mode**:
- Background: 0 0% 98% (off-white)
- Surface: 0 0% 100% (pure white)
- Text Primary: 0 0% 10% (near black)
- Text Secondary: 0 0% 40% (medium gray)

**Supporting Colors**:
- Success/Like: 142 70% 45% (music green, Spotify-inspired)
- Warning/Alert: 25 95% 53% (warm orange)
- Error: 0 84% 60% (vibrant red)

**Chart/Data Visualization**: Blue-teal spectrum (200°-160° hue range) for cohesive brand alignment

### B. Typography
**Primary Font**: Inter (Google Fonts)
- Headers: 600-700 weight
- Body: 400-500 weight
- UI Elements: 500 weight

**Sizes**:
- H1: text-4xl (large hero text)
- H2: text-2xl (section headers)
- H3: text-xl (card titles)
- Body: text-base
- Small: text-sm (metadata, timestamps)

### C. Layout System
**Spacing Units**: Tailwind 2, 4, 6, 8, 12, 16
- Component padding: p-4, p-6
- Section margins: mb-8, mb-12
- Card spacing: gap-4, gap-6
- Container max-width: max-w-6xl centered

### D. Component Library

**Navigation**:
- Bottom tab bar (mobile-first): Music, Discover, Profile, Messages
- Top header with search and notifications
- Sticky music player bar at bottom

**Content Cards**:
- Music post cards: Album art, artist info, social interactions
- User profile cards: Avatar, follower count, music preferences
- Playlist cards: Cover image, track count, creator info

**Music Player**:
- Mini player: Always visible bottom bar with play/pause, track info
- Full player: Expandable overlay with album art, controls, queue
- Waveform visualizations using CSS gradients

**Social Features**:
- Like/Share buttons with animation feedback
- Comment threads with nested replies
- Follow/Following buttons with status indicators

**Forms & Inputs**:
- Rounded input fields (rounded-lg)
- Purple focus states matching brand
- Form validation with inline error states

### E. Animations
**Minimal Usage**:
- Heart/Like button scale animation (scale-110 on tap)
- Loading spinners for music content
- Smooth page transitions (opacity + translateY)
- Music player expand/collapse animation

## Music-Specific Design Elements

**Album Art Integration**:
- Prominent square album covers throughout UI
- Gradient overlays for text readability
- Consistent 1:1 aspect ratio sizing

**Music Visualization**:
- Subtle waveform graphics using CSS gradients
- Progress bars with purple brand color
- Audio level indicators in chat/voice features

**Social Music Context**:
- "Now Playing" status indicators
- Shared playlist collaborative UI
- Music recommendation cards with "Add to Library" CTAs

## Content Strategy
- **Hero Section**: Featured playlists or trending artists
- **Discovery Feed**: Algorithm-based music recommendations
- **Social Feed**: Friend activity and music sharing
- **Profile Pages**: Personal music taste and social connections

This design creates a cohesive music-social experience that emphasizes content discovery while maintaining strong social networking patterns familiar to users.